<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

<title>Untitled Document</title>

</head>

<body>

        <footer class="footer">

            <div class="container-fluid">

                <nav class="pull-left">

                </nav>

                <p class="copyright pull-right">

                    Copyright &copy; <script>document.write(new Date().getFullYear())</script> Vaibhav_45. All rights reserved | Design by <a href="http://www.viiorr.com" target="_blank"> Viiorr</a>

                </p>

            </div>

        </footer>



</body>

</html>

