<?php
session_start();
?>
<?php
  function generate_random_password($length = 6) {
    $alphabets = range('A','Z');
    $numbers = range('0','9');
    $additional_characters = array('_','.');
    $final_array = array_merge($alphabets,$numbers,$additional_characters);
         
    $password = '';
  
    while($length--) {
      $key = array_rand($final_array);
      $password .= $final_array[$key];
    }
  
    return $password;
  }
   $pass=generate_random_password(15);
?>
<?php
$id=$pass;
$_SESSION['name']=$_POST['ename'];
$add=$_POST['eadd'];
$date=$_POST['edate'];
$desc=$_POST['edesc'];
$m_email=$_POST['e_m_name'];
$mevent=$_POST['mevent'];
$Path=$_FILES['txtFile']['name'];
if($m_email!="not" and $mevent!="not")
{
	error_reporting(E_ALL ^ E_DEPRECATED);
	$con=mysqli_connect("localhost","root","","joysworth");
	move_uploaded_file($_FILES['txtFile']['tmp_name'],"uploaded_image/".$_FILES['txtFile']['name']);
	$query="insert into event values('".$_SESSION['name']."','".$id."','".$date."','".$desc."','".$add."','".$m_email."','".$mevent."','".$Path."')";
	$result=mysqli_query($con,$query);
	mysqli_close($con);
	echo $Path;
	header("location:addevent.php");
}
else
{
	echo '<script type="text/javascript">alert("Please Select Appropriate Options");window.location=\'addevent.php\';</script>';
}
?>
