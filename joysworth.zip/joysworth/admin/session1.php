<?php
session_start();
if(isset($_SESSION['username']))
{
	if(isset($_SESSION['user']))
	{
		if(isset($_SESSION['password']))
		{
			header("location:userform.php");
		}
	}
	else if(isset($_SESSION['password']))
	{
		header("location:form.php");
	}
}
else
{
	echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';
}
?>