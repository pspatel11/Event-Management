<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
</head>
<style>
input[type="text"]
{
  width:150px;
  margin: 10px auto;
  background: rgba(255,255,255,0.1);
  border: none;
  font-size: 16px;
  height: auto;
  padding: 10px;
  background-color: #e8eeef;
  color: #8a97a0;
  box-shadow: 0 1px 0 rgba(0,0,0,0.03) inset;
  margin-bottom: 30px;
}

button {
  padding: 10px;
  color: #FFF;
  background-color: #4bc970;
  font-size: 16px;
  text-align: center;
  font-style: normal;
  border-radius: 5px;
  width: 25%;
  border: 1px solid #3ac162;
  border-width: 1px 1px 3px;
  box-shadow: 0 -1px 0 rgba(255,255,255,0.1) inset;
  margin-bottom: 10px;
}
.center
{
	width:300px;
	margin:0 auto;
}

</style>
<body>
<div class="center">
<form action="attensearch.php" method="post">
      
        
        
          <input id="name" name="name" required="required" type="text" autocomplete="off" placeholder="Enter Name">
          
          
        
        
        <button type="submit">Search</button>
      </form>
	  </div>
</body>
</html>
