<?php
session_start();
$_SESSION['pid']=$_POST['id'];
header('location:addperformances.php')
?>