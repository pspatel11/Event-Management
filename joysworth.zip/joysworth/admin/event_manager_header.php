<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link href="https://fonts.googleapis.com/css?family=Allura|Sacramento|Satisfy" rel="stylesheet">
</head>
<body>
<div class="sidebar" data-color="grey" data-image="assets/img/sidebar-5.jpg">

    <!--

        Tip 1: you can change the color of the sidebar using: data-color="blue | azure | green | orange | red | purple"
        Tip 2: you can also add an image using data-image tag

    -->

    	<div class="sidebar-wrapper">
            <div class="logo">
                <a href="#">
                <center><article style="font-family:'Sacramento', cursive; font-size:36px;">Joysworth</article></center>
                </a>
            </div>

            <ul class="nav">
                <li class="active">
                    <a href="userform.php">
                        <i class="pe-7s-airplay"></i>
                        <p>Register New User</p>
                    </a>
                </li>
                <li class="active">
                    <a href="listofparticipant.php">
                        <i class="pe-7s-user"></i>
                        <p>List Of Participated Users</p>
                    </a>
                </li>
				
				<li class="active">
                    <a href="addmulevent.php">
                        <i class="pe-7s-user"></i>
                        <p>Add Performances</p>
                    </a>
                </li>
				
				<li class="active">
                    <a href="event_upload_image.php">
                        <i class="pe-7s-user"></i>
                        <p>Add Image for event</p>
                    </a>
                </li>

				 <li>
                    <a href="logout.php">

<center>                        <article style="font-family:'Satisfy', cursive; font-size:24px;">Logout</article></center>
                    </a>
                </li>
            </ul>
			</article>
    	</div>
    </div>
</body>
</html>

