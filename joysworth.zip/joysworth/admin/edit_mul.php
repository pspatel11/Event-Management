<?php 
session_start();
if(isset($_SESSION['username']))
{
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Joysworth</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />
         
        <link rel="stylesheet" type="text/css" href="../css/style3.css" />
		<link rel="stylesheet" type="text/css" href="../css/animate-custom.css" />


    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
<script src="jquery.js" type="text/javascript"></script>
<script src="js-script.js" type="text/javascript"></script>
</head>

<body>
<div class="wrapper">
    <?php 
		include("header.php");
	?>

    <div class="main-panel">
        <?php 
include("navbar.php");
?>


 <div class="content">
   <div class="container-fluid">
<form method="post" action="update.php">
<table class='table table-bordered' border="0">
<?php
	error_reporting(E_ALL ^ E_DEPRECATED);
	$_SESSION['id']=$_GET['idu'];
	error_reporting(E_ALL ^ E_DEPRECATED);
	$con=mysqli_connect("localhost","root","","joysworth");
$check="select * from admin where uid='".$_SESSION['id']."'";
	$re=mysqli_query($con,$check);
	while($row=mysqli_fetch_array($re))
	{
		?>
		
		<tr>
		<td>Name</td>
		<td>
		<input type="text" name="name" value="<?php echo $row['name'];?>" class="form-control" />
        </td>
		</tr>
		<tr>
		<td>Email</td>
        <td>
		<input type="email" name="email" value="<?php echo $row['email'];?>" class="form-control" />
		</td></tr>
		
		<tr>
		<td>Address</td>
		<td>
		<input type="text" name="add" value="<?php echo $row['address'];?>" class="form-control" />
        </td>
		</tr>
		
		
		<tr>
		<td>Contact No.</td>
		<td>
		<input type="text" name="mob" value="<?php echo $row['contact'];?>" class="form-control" />
        </td>
		</tr>
		
		<tr>
		<td>Experience</td>
		<td>
		<input type="text" name="exp" value="<?php echo $row['experience'];?>" class="form-control" />
        </td>
		</tr>
		
		<tr>
		<td>Password</td>
		<td>
		<input type="text" name="password" value="<?php echo $row['password'];?>" class="form-control" />
        </td>
		</tr>
		
		<tr>
		<td colspan="2">
		<input type="submit" name="btn" value="Update" class="form-control" />
		</td>
		</tr>
		
		<?php	
	}			
?></table>
</form>

            </div>
        </div></div>
</div>


</body>


    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

		<?php
		
{
 if ((time() - $_SESSION['last_login_timestamp']) > 1500) 
 {
    header("location:logout.php");
    exit;
  } 
  else 
  {
    $_SESSION['last_login_timestamp'] = time();
  }
}
}
else
{
	echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';
}
?>



</html>
