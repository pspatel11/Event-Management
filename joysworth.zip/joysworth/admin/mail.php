<?php

session_start();

$mail=$_SESSION['email'];

error_reporting(E_ALL ^ E_DEPRECATED);
$con=mysqli_connect("localhost","root","","joysworth");
$query="select name from people_registration where email='".$mail."'";

$result=mysqli_query($con,$query);

$row=mysqli_fetch_array($result);

$n=$row['name'];

$Name='Vaidehi';

$url='http://celebrate.vaidehibabyshower.com/main.php?username='.$mail;

$Email='celebrate.vaidehibabyshower@gmail.com';

$Msg = "

 <html>

    <head>

    <title>Email From Vaidehi & Krunal</title>

	<link href='https://fonts.googleapis.com/css?family=Covered+By+Your+Grace|Reenie+Beanie' rel='stylesheet'>

    </head>

    <body  style='background-image:url(http://celebrate.vaidehibabyshower.com/images/9.png);'>

	<div align='center'>

	<br><br>

    <font color='#5a5a5a'><p align='center' style='font-family: Covered By Your Grace, cursive;'><b><big>An Invitation from Vaidehi & Krunal</big></b></p></font>

    <table>

	<col width='590'>

    <tr>

	<p>Hi,<b> $n</b></p>

    </tr>

    <tr>

	<font color='#258BA0'><p style='font-family: Reenie Beanie, cursive;'>You are cordially invited to come celebrate with us as we prepare to welcome our second baby girl and Shreeya is promoted to a BIG sister.</p>

	<p style='font-family: Reenie Beanie, cursive;'>Please click below to view invitation.</p></font>	

    </tr>

    </table>

	<table>

	<tr>

	<center><p style='font-family: Reenie Beanie, cursive;'><a href='".$url."'><font color='black'><button type='button'>Get Your Invitation card</button></font></a></p></center>

	</tr>
	
		<tr><center><p>OR</p></center></tr>
	
	<tr>
		<center><p style='font-family: Reenie Beanie, cursive;'><a href='".$url."'><font color='black'>Click here Get Your Invitation card</font></a></p></center>

	</tr>
	</table>

	</div>

    </body>

    </html>

	    ";


$to=$mail;

$subject='Welcome Baby Girl #2';

$headers='From:"Vaidehi & Krunal"<celebrate.vaidehibabyshower@gmail.com> '."\r\n" .

    'Reply-To:"Vaidehi & Krunal"<celebrate.vaidehibabyshower@gmail.com> '."\r\n" .

    'X-Mailer: PHP/' . phpversion();

$headers .= "MIME-Version: 1.0" . "\r\n";

    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\b";



@mail($to, $subject, $Msg, $headers);



error_reporting(E_ALL ^ E_DEPRECATED);
$con=mysqli_connect("localhost","root","","joysworth");
$query="update people_registration set mail=mail+1 where email='".$mail."'";

$result=mysqli_query($con,$query);

mysqli_close($con);

echo '<script type="text/javascript">alert("Registered Successfully & Email Sent");window.location=\'form.php\';</script>';

?>

