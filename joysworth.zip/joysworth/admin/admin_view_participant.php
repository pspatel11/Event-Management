<?php 
session_start();
if(isset($_SESSION['username']))
{
	
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<link rel="icon" type="image/png" href="assets/img/favicon.ico">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />

	<title>Joysworth</title>

	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />
    <meta name="viewport" content="width=device-width" />


    <!-- Bootstrap core CSS     -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />

    <!-- Animation library for notifications   -->
    <link href="assets/css/animate.min.css" rel="stylesheet"/>

    <!--  Light Bootstrap Table core CSS    -->
    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>


    <!--  CSS for Demo Purpose, don't include it in your project     -->
    <link href="assets/css/demo.css" rel="stylesheet" />
         
        <link rel="stylesheet" type="text/css" href="../css/style3.css" />
		<link rel="stylesheet" type="text/css" href="my.css" />
		<link rel="stylesheet" type="text/css" href="../css/animate-custom.css" />

<link href="https://fonts.googleapis.com/css?family=Allura|Sacramento|Satisfy" rel="stylesheet">
    <!--     Fonts and icons     -->
    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>
    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />
<script src="jquery.js" type="text/javascript"></script>
<script src="js-script.js" type="text/javascript"></script>
</head>

<body>
<div class="wrapper">
    <?php 
		include("header.php");
	?>

    <div class="main-panel">
        <?php 
include("navbar.php");
?>

 <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="header">
                                <h4 class="title"></h4>
                                <p class="category"></p>
                            </div>
                            <div class="content table-responsive table-full-width">
							<form method="post" name="frm">
								<table class="table table-hover table-striped" id="mytable">
                                    <thead>
                                    	<th id="nm">Name <img src="images/24967-200.png" width="20" height="20"></th>
										<th>Email</th>
 										<th>Contact No.</th>										
                                    	<th>Age</th>
                                    </thead>
                                   <tbody>
									
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$e_id=$_POST['id'];
if($e_id!="not")
{
error_reporting(E_ALL ^ E_DEPRECATED);
$con=mysqli_connect("localhost","root","","joysworth");
$query="select * from participant where e_id='".$e_id."'";
$result=mysqli_query($con,$query);
$count=mysqli_num_rows($result);
if($count>0)
{
while($row=mysqli_fetch_array($result))
{
	$p_id=$row['p_id'];
?>
		<tr>
			<?php
				$query1="select * from user where email='".$p_id."'";
				$result1=mysqli_query($con,$query1);
					while($row=mysqli_fetch_array($result1))
					{
						$name=$row['name'];
						$email=$row['email'];
						$mob=$row['contact'];
						$age=$row['age'];
			?>
							<td><?php echo $name;?></td>
							<td><?php echo $email;?></td>
                            <td><?php echo $mob;?></td>
							<td><?php echo $age;?></td>
							<td><a href="delete_userfrom_event.php?id=<?php echo $email;?>">Delete</a></td>
			
			<?php	
					}
			?>
		</tr>

<?php
}
}
else
{
?>
	<tr>
    	<td colspan="6"> No Records Found ...</td>
	</tr>
<?php
}
mysqli_close($con);
}
else
{
	echo '<script type="text/javascript">alert("Please Select Appropriate Option");window.location=\'admin_participant_event.php\';</script>';
}
?>



                                    </tbody>
                                </table>

                            </div>
                        </div>
						
                    </div>


                </div>
            </div>
        </div>

		</div>

</div>



</body>


    <!--   Core JS Files   -->
    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>
	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>

	<!--  Checkbox, Radio & Switch Plugins -->
	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>

	<!--  Charts Plugin -->
	<script src="assets/js/chartist.min.js"></script>

    <!--  Notifications Plugin    -->
    <script src="assets/js/bootstrap-notify.js"></script>

    <!--  Google Maps Plugin    -->
    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>

    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->
	<script src="assets/js/light-bootstrap-dashboard.js"></script>

	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->
	<script src="assets/js/demo.js"></script>

		<?php

 if ((time() - $_SESSION['last_login_timestamp']) > 1500) 
 {
    header("location:logout.php");
    exit;
  } 
  else 
  {
    $_SESSION['last_login_timestamp'] = time();
  }

}
else
{
	echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';
}
?>


<script>
function sortTable(f,n){
	var rows = $('#mytable tbody  tr').get();

	rows.sort(function(a, b) {

		var A = getVal(a);
		var B = getVal(b);

		if(A < B) {
			return -1*f;
		}
		if(A > B) {
			return 1*f;
		}
		return 0;
	});

	function getVal(elm){
		var v = $(elm).children('td').eq(n).text().toUpperCase();
		if($.isNumeric(v)){
			v = parseInt(v,10);
		}
		return v;
	}

	$.each(rows, function(index, row) {
		$('#mytable').children('tbody').append(row);
	});
}
var f_ss = 1;
var f_sl = 1;
var f_nm = 1;
var f_ns = 1;
$("#sl").click(function(){
    f_sl *= -1;
    var n = $(this).prevAll().length;
    sortTable(f_sl,n);
});

$("#nm").click(function(){
    f_nm *= -1;
    var n = $(this).prevAll().length;
    sortTable(f_nm,n);
});
$("#ss").click(function(){
    f_ss *= -1;
    var n = $(this).prevAll().length;
    sortTable(f_ss,n);
});

$("#ns").click(function(){
    f_ns *= -1;
    var n = $(this).prevAll().length;
    sortTable(f_ns,n);
});
</script>
</html>
