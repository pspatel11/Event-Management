<?php
session_start();
$id=$_SESSION['id'];
$name=$_POST['name'];
$add=$_POST['add'];
$mob=$_POST['mob'];
$exp=$_POST['exp'];
$pass=$_POST['password'];
$email=$_POST['email'];

error_reporting(E_ALL ^ E_DEPRECATED);
$con=mysqli_connect("localhost","root","","joysworth");
$query="update admin set password='".$pass."',name='".$name."',address='".$add."',contact='".$mob."',experience='".$exp."',email='".$email."' where uid='".$id."'";
$result=mysqli_query($con,$query);
mysqli_close($con);
echo '<script type="text/javascript">alert("Updated Successfully");window.location=\'listofpeoples.php\';</script>';
?>
