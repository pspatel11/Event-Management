<!DOCTYPE html>
<html class="full" lang="en">
<!-- Make sure the <html> tag is set to the .full CSS class. Change the background image in the full.css file. -->

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

	<title>Joysworth</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/the-big-picture.css" rel="stylesheet">
	         


		<link rel="stylesheet" type="text/css" href="jst.css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
	<script src='https://www.google.com/recaptcha/api.js'></script>
	<script>
var isCaptchaValidated = false;
var response = grecaptcha.getResponse();
if(response.length == 0) {
    isCaptchaValidated = false;
    toast('Please verify that you are a Human.');
} else {
    isCaptchaValidated = true;
}


if (isCaptchaValidated ) {
    //you can now submit your form
}	</script>
	
</head>

<body bgcolor="#CCCCCC">

    <!-- Navigation -->
    <!-- Page Content -->
    <div id="full">



<form action="session.php" method="post">
      
        <h1>Login</h1>
        
        <fieldset>

          <label for="name">Username</label>
          <input id="name" name="username" required="required" type="text" autocomplete="off" placeholder="Enter Email">
          
          <label for="mail">Password</label>
          <input type="password" id="mail" name="password" required="required" autocomplete="off" placeholder="*********"/>
		  
<!--		 <div class="g-recaptcha" name="recaptcha" id="g-recaptcha-response" data-sitekey="6Ld8thUUAAAAAE4TBO_ckRuzds1o_0ol6lXbUQps" data-callback='doSomething'></div>-->
		
                    
        </fieldset>
        
        <button type="submit">Login</button>
      </form>



        <!-- /.row -->
    </div>



    <!-- /.container -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
<script>	function doSomething() { alert(1); }</script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

</body>

</html>
