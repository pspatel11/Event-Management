<?php
session_start();
?>
<?php
  function generate_random_password($length = 6) {
    $alphabets = range('A','Z');
    $numbers = range('0','9');
    $additional_characters = array('_','.');
    $final_array = array_merge($alphabets,$numbers,$additional_characters);
         
    $password = '';
  
    while($length--) {
      $key = array_rand($final_array);
      $password .= $final_array[$key];
    }
  
    return $password;
  }
   $pass=generate_random_password(15);
?>
<?php
error_reporting(E_ALL ^ E_DEPRECATED);
$id=$pass;
$_SESSION['name']=$_POST['name'];
$add=$_POST['add'];
$mob=$_POST['mob'];
$exp=$_POST['exp'];
$pass=$_POST['pass'];
$_SESSION['email']=$_POST['email'];
$user=$_POST['user'];

if($user!="not")
{
	error_reporting(E_ALL ^ E_DEPRECATED);
	$con=mysqli_connect("localhost","root","","joysworth");
	$check="select * from admin where email='".$_SESSION['email']."'";
	$re=mysqli_query($con,$check);
	$count=mysqli_num_rows($re);
	if($count!=0)
	{
		echo '<script type="text/javascript">alert("Email Id already exist");window.location=\'form.php\';</script>';
	}
	else
	{
		error_reporting(E_ALL ^ E_DEPRECATED);
		$con=mysqli_connect("localhost","root","","joysworth");
		$query="insert into admin values('".$pass."','".$_SESSION['name']."','".$add."','".$mob."','".$exp."','".$user."','".$id."','".$_SESSION['email']."')";
		$result=mysqli_query($con,$query);
	}
	mysqli_close($con);
	header("location:form.php");
}
else
{
	echo '<script type="text/javascript">alert("Permission was not selected");window.location=\'form.php\';</script>';
}
?>