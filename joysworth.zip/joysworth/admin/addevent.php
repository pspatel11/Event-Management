<?php 

session_start();

if(isset($_SESSION['username']))

{

?>

<!doctype html>

<html lang="en">

<head>

	<meta charset="utf-8" />

	<link rel="icon" type="image/png" href="assets/img/favicon.ico">

	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />



	<title>Joysworth</title>



	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0' name='viewport' />

    <meta name="viewport" content="width=device-width" />





    <!-- Bootstrap core CSS     -->

    <link href="assets/css/bootstrap.min.css" rel="stylesheet" />



    <!-- Animation library for notifications   -->

    <link href="assets/css/animate.min.css" rel="stylesheet"/>



    <!--  Light Bootstrap Table core CSS    -->

    <link href="assets/css/light-bootstrap-dashboard.css" rel="stylesheet"/>





    <!--  CSS for Demo Purpose, don't include it in your project     -->

    <link href="assets/css/demo.css" rel="stylesheet" />

         

				<link rel="stylesheet" type="text/css" href="jst.css" />





    <!--     Fonts and icons     -->

    <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">

    <link href='http://fonts.googleapis.com/css?family=Roboto:400,700,300' rel='stylesheet' type='text/css'>

    <link href="assets/css/pe-icon-7-stroke.css" rel="stylesheet" />



</head>



<body>



<div class="wrapper">

    <?php 

		include("header.php");

	?>



    <div class="main-panel">

<?php 

include("navbar.php");

?>





        <div class="content">

            <div class="container-fluid">

					                    <div id="wrapper">

                        <div class="animate form">

<form action="eventregister.php" method="post" enctype="multipart/form-data">

      

        <h1>Register</h1>

        

        <fieldset>


          <label for="name">Event Name:</label>
          <input id="name" name="ename" required="required" type="text" autocomplete="off" placeholder="Enter Name">

          <label for="name">Event Address</label>
          <input id="name" name="eadd" required="required" type="text" autocomplete="off" placeholder="Enter Address">

          <label for="name">Event Date:</label>
          <input id="name" name="edate" required="required" type="date" autocomplete="off" placeholder="Enter Contact Number">

          <label for="name">Event Description:</label>
          <input id="name" name="edesc" required="required" type="text" autocomplete="off" placeholder="Enter Event Description">
		  
          
		  <label for="name">Multiple Events in it?:</label>
          <select name="mevent" required>
			<option value="not">Select</option>
			<option value="1">Yes</option>
			<option value="0">No</option>
			</select>
	
		  
		    <label for="name">Event Manager Name:</label>
			<select id="name" name="e_m_name" required="required">
			<option value="not">Select</option>
			<?php
				error_reporting(E_ALL ^ E_DEPRECATED);
				$con=mysqli_connect("localhost","root","","joysworth");
				$query="select * from admin where create_user=0";
				$result=mysqli_query($con,$query);
				$count=mysqli_num_rows($result);
				if($count!=0)
				{
					while($row=mysqli_fetch_array($result))
					{
					$st=$row['name'];
					$email=$row['email'];
					?>
					<option value="<?php echo $email;?>"><?php echo $st." (".$email.")";?></option>
			<?
				}
				}
				else
				{
				?>
				
					<h3> First Add Event Manager</h3>
				<?php 
				}
				mysqli_close($con);
			?>

			</select>

	          <label for="name">Choose Event Image:</label>
	    	  <input type="file" name="txtFile"  id="txtFile" required>

        </fieldset>

        

        <button type="submit">Register</button>

      </form>

	 
<table class="table table-hover table-striped" id="mytable">
	<thead>
		<th>Event Name</th>
		<th>Event Date</th>
		<th>Event Address</th>
		<th>Event Description</th>
		<th>Event Manager</th>
	</thead>
	<tbody>
		<?php
		error_reporting(E_ALL ^ E_DEPRECATED);
		
		
			error_reporting(E_ALL ^ E_DEPRECATED);
			$con=mysqli_connect("localhost","root","","joysworth");
			$query="select * from event";
			$result=mysqli_query($con,$query);
			$count=mysqli_num_rows($result);
			if($count==0)
			{
				?>
				<tr>
				<td>No record found</td>
				</tr>
			<?php
			}
			else
			{
				while($row=mysqli_fetch_array($result))
				{
					$id=$row['e_id'];
					$name=$row['e_name'];
					$date=$row['e_date'];
					$desc=$row['e_description'];
					$add=$row['e_address'];
					$e_m_email=$row['e_manager_email'];
					?>
					<tr>
					<td><?php echo $name;?></td>
					<td><?php echo $date;?></td>
					<td><?php echo $add;?></td>
					<td><?php echo $desc;?></td>
					<td>
						<?php 
								echo $e_m_email;
							
						?>
					</td>
					<td><a href="delete_event.php?id=<?php echo $id;?>">Delete</a></td>
					</tr>	
				
		<?php
			}
			}
			mysqli_close($con);
		?>
	</tbody>
</table>


                        </div>

						

                    </div>



                </div></div>

</div>





</body>





    <!--   Core JS Files   -->

    <script src="assets/js/jquery-1.10.2.js" type="text/javascript"></script>

	<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>



	<!--  Checkbox, Radio & Switch Plugins -->

	<script src="assets/js/bootstrap-checkbox-radio-switch.js"></script>



	<!--  Charts Plugin -->

	<script src="assets/js/chartist.min.js"></script>



    <!--  Notifications Plugin    -->

    <script src="assets/js/bootstrap-notify.js"></script>



    <!--  Google Maps Plugin    -->

    <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>



    <!-- Light Bootstrap Table Core javascript and methods for Demo purpose -->

	<script src="assets/js/light-bootstrap-dashboard.js"></script>



	<!-- Light Bootstrap Table DEMO methods, don't include it in your project! -->

	<script src="assets/js/demo.js"></script>



<?php



 if ((time() - $_SESSION['last_login_timestamp']) > 1500) 

 {

    header("location:logout.php");

    exit;

  } 

  else 

  {

    $_SESSION['last_login_timestamp'] = time();

  }

}

}

else

{

	echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';

}

?>



</html>



