<?php
session_start();
if($e_id=$_POST['event']!='not')
{
?>
<?php
  function generate_random_password($length = 6) {
    $alphabets = range('A','Z');
    $numbers = range('0','9');
    $additional_characters = array('_','.');
    $final_array = array_merge($alphabets,$numbers,$additional_characters);
         
    $password = '';
  
    while($length--) {
      $key = array_rand($final_array);
      $password .= $final_array[$key];
    }
  
    return $password;
  }
   $pass=generate_random_password(15);
   
   $id=$pass;
	$e_id=$_POST['event'];
	$Path=$_FILES['txtFile']['name'];
	error_reporting(E_ALL ^ E_DEPRECATED);
	$con=mysqli_connect("localhost","root","","joysworth");
	
		move_uploaded_file($_FILES['txtFile']['tmp_name'],"uploaded_image/".$_FILES['txtFile']['name']);
		$query="insert into gallery values('".$id."','".$Path."','".$e_id."')";
		$result=mysqli_query($con,$query);
		if(isset($_SESSION['user']))
		{
			echo '<script type="text/javascript">alert("File Uploaded Succesfully");window.location=\'event_upload_image.php\';</script>';
		}
		else
		{
			echo '<script type="text/javascript">alert("File Uploaded Succesfully");window.location=\'addimage.php\';</script>';
		}
		mysqli_close($con);
	}
	else
	{
		if(isset($_SESSION['user']))
		{
			echo '<script type="text/javascript">alert("Please Select Event");window.location=\'event_upload_image.php\';</script>';
		}
		else
		{
			echo '<script type="text/javascript">alert("Please Select Event");window.location=\'addimage.php\';</script>';
		}
	}
?>
