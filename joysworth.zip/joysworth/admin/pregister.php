<?php
$id=$_POST['pid'];
$name=$_POST['pname'];

	error_reporting(E_ALL ^ E_DEPRECATED);
	$con=mysqli_connect("localhost","root","","joysworth");
	$query="insert into performance values('".$name."','".$id."')";
	$result=mysqli_query($con,$query);
	mysqli_close($con);
	header("location:addperformances.php");
?>
