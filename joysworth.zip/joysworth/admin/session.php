<?php
$user=$_POST['username'];
$pass=$_POST['password'];
error_reporting(E_ALL ^ E_DEPRECATED);
$con=mysqli_connect("localhost","root","","joysworth");
$query="select create_user from admin where email='".$user."'";
$result=mysqli_query($con,$query);
$row=mysqli_fetch_array($result);
$us=$row['create_user'];
if($us==1)
{
	$query="select * from admin where email='".$user."' and password='".$pass."'";
	$result=mysqli_query($con,$query);
	$count=mysqli_num_rows($result);
		if($count!=0)
		{
	
			session_start();
			$_SESSION['username']=$user;
			$_SESSION['password']=$pass;
			$_SESSION['last_login_timestamp'] = time();
			header("location:session1.php");
		}
		else
		{
			echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';
		}
}
else if($us==0)
{
	$query="select * from admin where email='".$user."' and password='".$pass."'";
	$result=mysqli_query($con,$query);
	$count=mysqli_num_rows($result);
		if($count!=0)
		{
	
			session_start();
			$_SESSION['username']=$user;
			$_SESSION['password']=$pass;
			$_SESSION['user']="user";
			$_SESSION['last_login_timestamp'] = time();
			header("location:session1.php");
		}
		else
		{
			echo '<script type="text/javascript">alert("Wrong Username & Password");window.location=\'index.php\';</script>';
		}
}
?>